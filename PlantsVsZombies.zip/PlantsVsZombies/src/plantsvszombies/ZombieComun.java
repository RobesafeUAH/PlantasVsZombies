/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author aleja
 */
public class ZombieComun extends Zombie{

    public ZombieComun(int vida, int daño, String comportamiento, int velocidad) {
        super(vida, daño, comportamiento, velocidad);
    }
}
