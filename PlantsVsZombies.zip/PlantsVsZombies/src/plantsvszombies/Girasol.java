/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author jonathan y alejandro
 */
public class Girasol extends Planta {
    private int solesGen;
    /**
     * Constructor de la clase Girasol que va a heredar atributos de la clase Planta.
     * @param solesGen
     * @param vida
     * @param daño
     * @param comportamiento
     * @param coste
     * @param frecuencia 
     */
    public Girasol(int solesGen ,int vida, int daño, String comportamiento, int coste, int frecuencia) {
        super(vida, daño, comportamiento, coste, frecuencia);
        this.solesGen=solesGen;
    }
/**
 * metodos get y set de SolesGen que utilizaremos para ver cuantos soloes genera un girasol.
 * @return soles generados
 */
    public int getSolesGen() {
        return solesGen;
    }
    
    public void setSolesGen(int solesGen) {
        this.solesGen = solesGen;
    }
    
}
