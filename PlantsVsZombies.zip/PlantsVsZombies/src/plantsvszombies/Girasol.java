/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author aleja
 */
public class Girasol extends Planta {
    private int solesGen;
    public Girasol(int vida, int daño, String comportamiento, int coste, int frecuencia) {
        super(vida, daño, comportamiento, coste, frecuencia);
        this.solesGen=solesGen;
    }

    public int getSolesGen() {
        return solesGen;
    }

    public void setSolesGen(int solesGen) {
        this.solesGen = solesGen;
    }
    
}
