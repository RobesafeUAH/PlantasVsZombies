/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author jonathan y alejandro
 */
public class Planta extends Personaje {
    private int coste;
    private int frecuencia;
    /**
     * Constructor de la clase Planta que hereda de la clase Personaje y es la clase padre de todas las plantas
     * @param vida
     * @param daño
     * @param comportamiento
     * @param coste
     * @param frecuencia 
     */
    public Planta(int vida, int daño, String comportamiento, int coste, int frecuencia) {
        super(vida, daño, comportamiento);
        this.coste=coste;
        this.frecuencia=frecuencia;
    }
/**
 * Metodos getter y setter con los que consultar o modificar los atributos de las plantas
 * 
 */
    public int getCoste() {
        return coste;
    }

    public void setCoste(int coste) {
        this.coste = coste;
    }

    public int getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia(int frecuencia) {
        this.frecuencia = frecuencia;
    }
    /**
     * Metodo que resta la frecuencia para controlar los ciclos de disparo
     */
    public void restarFrecuencia(){
        this.frecuencia= this.frecuencia-1;
    }
}
