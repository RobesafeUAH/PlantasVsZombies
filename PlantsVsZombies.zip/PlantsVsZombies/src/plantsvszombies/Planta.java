/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author aleja
 */
public class Planta extends Personaje {
    private int coste;
    private int frecuencia;
    public Planta(int vida, int daño, String comportamiento, int coste, int frecuencia) {
        super(vida, daño, comportamiento);
        this.coste=coste;
        this.frecuencia=frecuencia;
    }

    public int getCoste() {
        return coste;
    }

    public void setCoste(int coste) {
        this.coste = coste;
    }

    public int getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia(int frecuencia) {
        this.frecuencia = frecuencia;
    }
    public void restarFrecuencia(){
        this.frecuencia= this.frecuencia-1;
    }
}
