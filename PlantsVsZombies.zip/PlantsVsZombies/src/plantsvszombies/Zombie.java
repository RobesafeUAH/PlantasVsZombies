/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author jonathan y alejandro
 */
public class Zombie extends Personaje{
    private int velocidad;
/**
 * Constructor de la clase Zombie que hereda los atributos de la clase Personaje
 * @param vida
 * @param daño
 * @param comportamiento
 * @param velocidad 
 */
    public Zombie(int vida, int daño, String comportamiento, int velocidad) {
        super(vida, daño, comportamiento);
        this.velocidad=velocidad;
    }
/**
 * Metodos getter y setter de la velocidad del zombie
 * 
 */
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
}
