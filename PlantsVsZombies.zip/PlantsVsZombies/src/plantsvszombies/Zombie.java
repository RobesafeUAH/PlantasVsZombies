/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author aleja
 */
public class Zombie extends Personaje{
    private int velocidad;

    public Zombie(int vida, int daño, String comportamiento, int velocidad) {
        super(vida, daño, comportamiento);
        this.velocidad=velocidad;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
}
