package plantsvszombies;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jonathan y alejandro
 */
public class Juego {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // TODO code application logic here
        ZombieComun z = new ZombieComun(5, 1, "Avanza y come plantas", 2);
        System.out.println("Comienza el juego");
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la dificultad del juego(Baja,Media,Alta,Imposible): ");
        System.out.print(">");
        String dificultad = sc.nextLine().toUpperCase();
        System.out.println("");
        dificultad=ExcepcionComando.dificultad(dificultad);
        Tablero t = new Tablero(7, 7, 50, dificultad.toUpperCase(), 0);
        t.rellenarTablero();
        t.imprimirTablero();
        System.out.println("(Teclear ayuda para lista de comandos.<Enter> para terminar el turno.)");
        System.out.print(">");
        String comando = sc.nextLine().toUpperCase();
        String cPlanta="";
        String cFila="";
        String cColumna="";
        String cStr="";
        if (ExcepcionComando.division(comando)) {
        cPlanta=comando.split(" ")[0];
        cFila=comando.split(" ")[1];
        cColumna=comando.split(" ")[2];
        }else{
        cStr=comando;
        }
        int fila=0;
        int columna=0;
        while (!t.finPartida() && t.getTurno() < 30) {
            while (!t.finPartida() && t.getTurno() < 30 && !"S".equals(comando)) {
                while (!t.finPartida() && !"".equals(cPlanta)) {
                if (ExcepcionComando.cadenaAInt(cFila, cColumna)) {
                fila=Integer.parseInt(cFila);
                columna=Integer.parseInt(cColumna); 
                }else{
                System.out.println("Introduzca un valor numérico para la fila y columna");
                }
                    if (ExcepcionComando.division(comando)) {                    
                    if (cPlanta.equals("G") && ExcepcionComando.division(comando)) {
                        t.plantarGirasol(fila, columna);
                        t.imprimirTablero();
                    } else if (cPlanta.equals("L") && ExcepcionComando.division(comando)) {
                        t.plantarLanzaguisantes(fila, columna);
                        t.imprimirTablero();
                    } else if (cPlanta.equals("N") && ExcepcionComando.division(comando)) {
                        t.plantarNuez(fila, columna);
                        t.imprimirTablero();
                    }
                    }else if (cStr.equals("AYUDA")) {
                        t.ayuda();
                    } else if (cStr.equals("")) {
                        break;
                    }
                    System.out.println("L para LanzaGuisantes, G para Girasol o N para Nuez.Enter para pasar de turno.");
                    comando = sc.nextLine().toUpperCase();
                    if (ExcepcionComando.division(comando)) {
                    cPlanta=comando.split(" ")[0];
                    cFila=comando.split(" ")[1];
                    cColumna=comando.split(" ")[2];
                    }else{
                    cStr=comando;
                    }
                }
                if (!t.finPartida()) {
                    System.out.println("Siguiente turno.");
                    t.pasarTurno();
                    if (t.getTurno() >= 10 && dificultad.equals("BAJA")) {
                        t.generarZombie();
                    } else if (t.getTurno() >= 7 && dificultad.equals("MEDIA")) {
                        t.generarZombie();
                    } else if (t.getTurno() >= 5 && (dificultad.equals("ALTA") || dificultad.equals("IMPOSIBLE"))) {
                        t.generarZombie();
                    }
                    t.siguienteTurno();
                    t.imprimirTablero();
                    if (comando.equals("")) {
                        System.out.println("L para LanzaGuisantes, G para Girasol o N para Nuez.Enter para pasar de turno.");
                        comando = sc.nextLine().toUpperCase();
                    }
                }
            }
            if (t.finPartida()) {
                System.out.println("Los zombies han llegado,¡HAS PERDIDO!");
            } else if (t.getTurno() >= 30) {
                System.out.println("Los zombies no han podido contigo,¡HAS GANADO!");
            } else if ("S".equals(comando)) {
                System.out.println("Saliendo del juego.");
            }
            System.out.println("FIN DE LA PARTIDA");
            break;
        }
    }
}
