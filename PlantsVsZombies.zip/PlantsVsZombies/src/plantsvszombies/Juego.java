package plantsvszombies;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jonathan y alejandro
 */
public class Juego {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // TODO code application logic here
        ZombieComun z = new ZombieComun(5, 1, "Avanza y come plantas", 2);
        System.out.println("Comienza el juego");
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la dificultad del juego(Baja,Media,Alta,Imposible): ");
        System.out.print(">");
        String dificultad = sc.nextLine().toUpperCase();
        System.out.println("");
        Tablero t = new Tablero(7, 7, 50, dificultad.toUpperCase(), 0);
        t.rellenarTablero();
        t.imprimirTablero();
        System.out.println("(Teclear ayuda para lista de comandos.<Enter> para terminar el turno.)");
        System.out.print(">");
        String comando = sc.nextLine().toUpperCase();
        while (!t.finPartida() && t.getTurno() < 30) {
            while (!t.finPartida() && t.getTurno() < 30 && !"S".equals(comando)) {
                while (!t.finPartida() && !"".equals(comando)) {
                    if (comando.equals("G")) {
                        t.plantarGirasol();
                        t.imprimirTablero();
                    } else if (comando.equals("L")) {
                        t.plantarLanzaguisantes();
                        t.imprimirTablero();
                    } else if (comando.equals("N")) {
                        t.plantarNuez();
                        t.imprimirTablero();
                    }else if (comando.equals("AYUDA")) {
                        t.ayuda();
                    } else if (comando.equals("")) {
                        break;
                    }
                    System.out.println("L para LanzaGuisantes, G para Girasol o N para Nuez.Enter para pasar de turno.");
                    comando = sc.nextLine().toUpperCase();
                }
                if (!t.finPartida()) {
                    System.out.println("Siguiente turno.");
                    t.pasarTurno();
                    if (t.getTurno() >= 10 && dificultad.equals("BAJA")) {
                        t.generarZombie();
                    } else if (t.getTurno() >= 7 && dificultad.equals("MEDIA")) {
                        t.generarZombie();
                    } else if (t.getTurno() >= 5 && (dificultad.equals("ALTA") || dificultad.equals("IMPOSIBLE"))) {
                        t.generarZombie();
                    }
                    t.siguienteTurno();
                    t.imprimirTablero();
                    if (comando.equals("")) {
                        System.out.println("L para LanzaGuisantes, G para Girasol o N para Nuez.Enter para pasar de turno.");
                        comando = sc.nextLine().toUpperCase();
                    }
                }
            }
            if (t.finPartida()) {
                System.out.println("Los zombies han llegado,¡HAS PERDIDO!");
            } else if (t.getTurno() >= 30) {
                System.out.println("Los zombies no han podido contigo,¡HAS GANADO!");
            } else if ("S".equals(comando)) {
                System.out.println("Saliendo del juego.");
            }
            System.out.println("FIN DE LA PARTIDA");
            break;
        }
    }
}
