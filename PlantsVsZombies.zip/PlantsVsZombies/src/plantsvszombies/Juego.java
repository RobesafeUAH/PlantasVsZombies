package plantsvszombies;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aleja
 */
public class Juego {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
        System.out.print("Comienza el juego");
        System.out.print("");
        Scanner sc= new Scanner(System.in);
        System.out.print("Introduzca el número de filas del tablero: ");
        int filas= sc.nextInt();
        System.out.print("Introduzca el número de columnas del tablero: ");
        int columnas= sc.nextInt();
        System.out.print("Introduzca la dificultad del juego: ");
        String dificultad= sc.nextLine();
        Tablero t= new Tablero(filas,columnas,50,dificultad.toUpperCase(),0);
        t.imprimirTablero();
        t.rellenarTablero();
        System.out.print("Es su turno, escriba ayuda para ver los comandos y enter para pasar de turno: ");
        String comando=sc.nextLine();
        while(!t.finPartida()&& t.getTurno()<40 && !comando.equals("S")){
            while(!t.finPartida() && !comando.equals("")){
                if (comando.equals("G")) {
                    t.plantarGirasol();
                    t.imprimirTablero();
                }else if (comando.equals("L")) {
                    t.plantarLanzaguisantes();
                    t.imprimirTablero();
                }else if (comando.equals("")) {
                    break;
                }
                System.out.print("Es su turno, escriba ayuda para ver los comandos y enter para pasar de turno: ");
                comando=sc.nextLine();
            }
            if (!t.finPartida()) {
                System.out.println("Ha pasado turno");
                t.pasarTurno();
                if (t.getTurno()>=10) {
                    t.generarZombie();
                }
                t.siguienteTurno();
                t.imprimirTablero();
                System.out.print("Es su turno, escriba ayuda para ver los comandos y enter para pasar de turno: ");
                comando=sc.nextLine();
            }
        }
        if (t.finPartida()) {
            System.out.println("¡Los zombies han llegado! Ha perdido");
        }else if (t.getTurno()>=30) {
            System.out.println("¡Ya no quedan zombies! Ha ganado");
        }else if (comando.equals("S")) {
            System.out.println("Has salido del juego");
        }
        System.out.print("Fin del juego");
    }
    
}
