/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author aleja
 */
public class Tablero {
    private ArrayList<Personaje> tablero;
    private int nFilas;
    private int nColumnas;
    private int nSoles;
    private String modo;
    private int contZombies;
    private int turno;
    private String dificultad;

    public Tablero( int nFilas, int nColumnas, int nSoles, String modo, int turno) {
        this.tablero = new ArrayList<>();
        this.nFilas = nFilas;
        this.nColumnas = nColumnas;
        this.nSoles = nSoles;
        this.modo = modo;
        this.turno=turno;
        
        if (modo.equals("BAJA")) {
            this.contZombies=5;
        }
        if (modo.equals("MEDIA")) {
            this.contZombies=15;
        }
        if (modo.equals("ALTA")) {
            this.contZombies=25;
        }
        if (modo.equals("IMPOSIBLE")) {
            this.contZombies=50;
        } 
    }

    public ArrayList<Personaje> getTablero() {
        return tablero;
    }

    public void setTablero(ArrayList<Personaje> tablero) {
        this.tablero = tablero;
    }

    public int getNFilas() {
        return nFilas;
    }

    public void setNFilas(int nFilas) {
        this.nFilas = nFilas;
    }

    public int getNColumnas() {
        return nColumnas;
    }

    public void setNColumnas(int nColumnas) {
        this.nColumnas = nColumnas;
    }

    public int getNSoles() {
        return nSoles;
    }

    public void setNSoles(int nSoles) {
        this.nSoles = nSoles;
    }

    public String getModo() {
        return modo;
    }

    public void setModo(String modo) {
        this.modo = modo;
    }

    public int getContZombies() {
        return contZombies;
    }

    public void setContZombies(int contZombies) {
        this.contZombies = contZombies;
    }

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }
    public void siguienteTurno(){
        this.turno=turno+1;
    }

    public String getDificultad() {
        return dificultad;
    }

    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }
    
    public void imprimirTablero(){
        for (int i = 0; i < nFilas; i++) {
            for (int j = 0; j < nColumnas; j++) {
                System.out.print("|--------|");
            }
            System.out.print("");
            for (int j = 0; j < nColumnas; j++) {
                if (tablero.get(i +nColumnas + j)==null) {
                    System.out.print("|        |");
                }
                else if (tablero.get(i +nColumnas + j).getClass().getSimpleName().equals("Girasol")) {
                    System.out.print("|  G(|"+tablero.get(i + nColumnas + j).getVida() + ")  ");
                }
                else if (tablero.get(i +nColumnas + j).getClass().getSimpleName().equals("Lanzaguisante")) {
                    System.out.print("|  L(|"+tablero.get(i + nColumnas + j).getVida() + ")  ");
                }
                else if (tablero.get(i +nColumnas + j).getClass().getSimpleName().equals("ZombieComun")) {
                    System.out.print("|  Z(|"+tablero.get(i + nColumnas + j).getVida() + ")  ");
                }
            }
            System.out.print("");
        }
        for (int i = 0; i < nColumnas; i++) {
            System.out.print("|--------|");
        }
        System.out.print("");
        System.out.print("Tienes" + nSoles + "soles");
        System.out.print("Turno:" + getTurno());
    }
    public void rellenarTablero(){
        for (int i = 0; i < nFilas + nColumnas; i++) {
            tablero.add(null);
        }
    }
    public void plantarGirasol(){
        Scanner sc=new Scanner(System.in);
        System.out.print("Escriba la columna:");
        int columna= sc.nextInt();
        System.out.print("Escriba la fila:");
        int fila=sc.nextInt();
        int pos= fila+columna;
        if (this.nSoles>=20 && tablero.get(pos)==null){
            Girasol g= new Girasol (1,0,"genera soles", 20,0);
            tablero.set(pos, g);
            this.nSoles=this.nSoles-20;
        }else{
            if (this.nSoles<20 && tablero.get(pos)!=null) {
                System.out.print("No tiene suficientes soles y la casilla está ocupada");
            }else if (this.nSoles<20) {
                System.out.print("No tiene suficientes soles");
            }else{
                System.out.print("La casilla está ocupada");
            }
        }
    }
    public void plantarLanzaguisantes(){
        Scanner sc=new Scanner(System.in);
        System.out.print("Escriba la columna:");
        int columna= sc.nextInt();
        System.out.print("Escriba la fila:");
        int fila=sc.nextInt();
        int pos= fila+columna;
        if (this.nSoles>=50 && tablero.get(pos)==null){
            Lanzaguisantes l= new Lanzaguisantes (3,1,"dispara recto hacia delante", 50,1,0);
            tablero.set(pos, l);
            this.nSoles=this.nSoles-50;
        }else{
            if (this.nSoles<50 && tablero.get(pos)!=null) {
                System.out.print("No tiene suficientes soles y la casilla está ocupada");
            }else if (this.nSoles<50) {
                System.out.print("No tiene suficientes soles");
            }else{
                System.out.print("La casilla está ocupada");
            }
        }
    }
    public void ingresarSoles(){
        for (int i = 0; i < tablero.size(); i++) {
            if (tablero.get(i)!=null && tablero.get(i).getClass().getSimpleName().equals("Girasol")) {
                Girasol g= (Girasol) tablero.get(i);
                if (g.getFrecuencia()!=0) {
                    g.restarFrecuencia();
                }else{
                    this.nSoles=this.nSoles+g.getSolesGen();
                    g.setFrecuencia(2);
                }
            }
        }
    }
    public void dispararRecto(){
        for (int i = 0; i < tablero.size(); i++) {
            if (tablero.get(i)!=null && tablero.get(i).getClass().getSimpleName().equals("Lanzaguisantes")) {
                int filaDisparo=1/nColumnas;
                int filaFinal= (filaDisparo+1)*nColumnas;
                for (int j = 0; filaFinal < 10; j++) {
                    if (tablero.get(i)!=null && tablero.get(i).getClass().getSimpleName().equals("ZombieComun")) {
                        Lanzaguisantes l=(Lanzaguisantes) tablero.get(i);
                        ZombieComun z= (ZombieComun) tablero.get(i);
                        z.recibirDaño(l.getDaño());
                        System.err.print(l.getDaño());
                        if (z.getVida()==0) {
                            tablero.set(i, null);
                        }break;
                    }
                }
            }
        }
    }
    public void avanzar(){
        for (int i = 0; i < tablero.size(); i++) {
            if (tablero.get(i)!=null && tablero.get(i).getClass().getSimpleName().equals("ZombieComun")) {
                if (tablero.get(i-1)!=null && (tablero.get(i).getClass().getSimpleName().equals("Girasol")
                        ||tablero.get(i).getClass().getSimpleName().equals("Lanzaguisantes"))) {
                    tablero.get(i-1).recibirDaño(tablero.get(i).getDaño());
                    if (tablero.get(i-1).getVida()==0) {
                        tablero.set(i-1,null);
                    }
                }else{
                    ZombieComun z= (ZombieComun) tablero.get(i);
                    if (z.getVelocidad()==1) {
                        tablero.set(i-1,z);
                        tablero.set(i, null);
                        z.setVelocidad(2);
                    }else{
                        z.setVelocidad(z.getVelocidad()-1);
                    }
                }
            }
        }
    }
    public void generarZombie(){
        int pos=nColumnas -1;
        ArrayList<Integer> posPosibles= new ArrayList<>();
        for (int i = 0; i < nFilas; i++) {
            if (tablero.get(pos)==null) {
                posPosibles.add(pos);
                pos=pos+nColumnas;
            }
        }
        Collections.shuffle(posPosibles);
        if (this.dificultad.equals("BAJA")) {
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if (resultado==0 && !posPosibles.isEmpty()) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                }
            }
        }else if (this.dificultad.equals("MEDIA")) {
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if ((resultado==0||resultado==1) && !posPosibles.isEmpty()) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0),z);
                    contZombies=contZombies-1;
                }
            }
            
        }else if (this.dificultad.equals("ALTA")) {
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if (resultado==0 && !posPosibles.isEmpty()) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                }
                if (resultado==1 && posPosibles.size()>=2) {
                    ZombieComun z1= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z1);
                    contZombies=contZombies-1;
                    ZombieComun z2= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z2);
                    contZombies=contZombies-1;
                    }
                if (resultado==1 && posPosibles.size()>=1) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                }
                }
        }else if (this.dificultad.equals("IMPOSIBLE")){
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if (resultado==0) {
                    int spawnZombies;
                    if (posPosibles.size()>=4) {
                        spawnZombies=4;
                    }else{
                    spawnZombies=posPosibles.size();
                    }
                    for (int i = 0; i < spawnZombies; i++) {
                        ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                        tablero.set(posPosibles.get(i),z);
                        contZombies=contZombies-1;
                    }
                }else if (resultado==1) {
                    int spawnZombies;
                    if (posPosibles.size()>=3) {
                        spawnZombies=3;
                    }else{
                    spawnZombies=posPosibles.size();
                    }
                    for (int i = 0; i < spawnZombies; i++) {
                        ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                        tablero.set(posPosibles.get(i),z);
                        contZombies=contZombies-1;
                    }
                }else if (resultado==2) {
                    int spawnZombies;
                    if (posPosibles.size()>=2) {
                        spawnZombies=2;
                    }else{
                    spawnZombies=posPosibles.size();
                    }
                    for (int i = 0; i < spawnZombies; i++) {
                        ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                        tablero.set(posPosibles.get(i),z);
                        contZombies=contZombies-1;
                    }
                }
                else if (resultado==3) {
                    if (!posPosibles.isEmpty()) {
                        ZombieComun z=new ZombieComun(5,1,"Avanza y come plantas",2);
                        tablero.set(posPosibles.get(0),z);
                        contZombies=contZombies-1;
                    }
                }
            }
        }
    }
    public void pasarTurno(){
        avanzar();
        dispararRecto();
        ingresarSoles();

    }
    public boolean finPartida(){
        int pos=0;
        for (int i = 0; i < nFilas; i++) {
            if (tablero.get(pos)!=null && tablero.get(pos).getClass().getSimpleName().equals("ZombieComun")) {
                return true;
            }
            pos=pos+nColumnas;
        }
        return false;
    }
}
