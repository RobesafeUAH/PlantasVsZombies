/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author jonathan y alejandro
 */
public class Tablero {
    private ArrayList<Personaje> tablero;
    private int nFilas;
    private int nColumnas;
    private int nSoles;
    private String modo;
    private int contZombies;
    private int turno;
/**
 * Este es el metodo constructor que utilizaremos para crear el objeto tablero.
 * @param nFilas
 * @param nColumnas
 * @param nSoles
 * @param modo
 * @param turno 
 */
    public Tablero( int nFilas, int nColumnas, int nSoles, String modo, int turno) {
        this.tablero = new ArrayList<>();
        this.nFilas = nFilas;
        this.nColumnas = nColumnas;
        this.nSoles = nSoles;
        this.modo = modo;
        this.turno=turno;
        
        if (modo.equals("BAJA")) {
            this.contZombies=5;
        }
        if (modo.equals("MEDIA")) {
            this.contZombies=15;
        }
        if (modo.equals("ALTA")) {
            this.contZombies=25;
        }
        if (modo.equals("IMPOSIBLE")) {
            this.contZombies=50;
        } 
    }
/**
 *Aqui pondremos todos los metodos getter y setter de los que sacaremos valores o modificaremos valores del objeto tablero.
 */
    
    public ArrayList<Personaje> getTablero() {
        return tablero;
    }

    public void setTablero(ArrayList<Personaje> tablero) {
        this.tablero = tablero;
    }

    public int getNFilas() {
        return nFilas;
    }

    public void setNFilas(int nFilas) {
        this.nFilas = nFilas;
    }

    public int getNColumnas() {
        return nColumnas;
    }

    public void setNColumnas(int nColumnas) {
        this.nColumnas = nColumnas;
    }

    public int getNSoles() {
        return nSoles;
    }

    public void setNSoles(int nSoles) {
        this.nSoles = nSoles;
    }

    public String getModo() {
        return modo;
    }

    public void setModo(String modo) {
        this.modo = modo;
    }

    public int getContZombies() {
        return contZombies;
    }

    public void setContZombies(int contZombies) {
        this.contZombies = contZombies;
    }

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }
    /**
     * Este metodo lo utilizaremos para incrementar en uno el turno en el que estemos y asi poder avanzar en el juego.
     */
    public void siguienteTurno(){
        this.turno=turno+1;
    }
    /**
     * Con este metodo lo que conseguiremos es imprimir nuestro tablero por pantalla, aunque antes deberias hacer uso del metodo
     * rellenar tablero, para que llene de valores NULL el array tablero y asi hacer que este metodo funcione correctamente.
     * @see rellenarTablero();
     */
    public void imprimirTablero(){
        for (int i = 0; i < nFilas; i++) {
            for (int j = 0; j < nColumnas; j++) {
                System.out.print("|--------|");
            }
            System.out.println("");
            for (int j = 0; j < nColumnas; j++) {
                if (tablero.get(i *nColumnas + j) == null) {
                    System.out.print("|        |");
                }
                else if (tablero.get(i *nColumnas + j).getClass().getSimpleName().equals("Girasol")) {
                    System.out.print("|  G("+tablero.get(i * nColumnas + j).getVida() + ")  |");
                }
                else if (tablero.get(i *nColumnas + j).getClass().getSimpleName().equals("Lanzaguisantes")) {
                    System.out.print("|  L("+tablero.get(i * nColumnas + j).getVida() + ")  |");
                }
                else if (tablero.get(i *nColumnas + j).getClass().getSimpleName().equals("ZombieComun")) {
                    System.out.print("|  Z("+tablero.get(i * nColumnas + j).getVida() + ")  |");
                }else if (tablero.get(i *nColumnas + j).getClass().getSimpleName().equals("Nuez")) {
                    System.out.print("|  N("+tablero.get(i * nColumnas + j).getVida() + ")  |");
                }
            }
            System.out.println("");
        }
        for (int i = 0; i < nColumnas; i++) {
            System.out.print("|--------|");
        }
        System.out.println("");
        System.out.println("Tienes " + nSoles + " soles");
        System.out.println("Turno:" + getTurno());
    }
    /**
     * Este metodo lo utilizaremos para rellenar el array tablero de valores null.
     */
    public void rellenarTablero(){
        for (int i = 0; i < nFilas * nColumnas; i++) {
            tablero.add(null);
        }
    }
    /**
     * Con este metodo pediremos al usuario una fila y una columna. A continuacion miraremos si el jugador tiene los soles suficientes y
     * comprobaremos que en las coordenadas dadas no haya otro objeto y una vez comprobado eso, colocaremos dentro del array tablero el objeto girasol
     * en las coordenadas dadas.
     */
    public void plantarGirasol(int fila, int columna){
        int pos= fila*nColumnas+columna;
        if (this.nSoles>=20 && tablero.get(pos)==null){
            Girasol g= new Girasol (20,1,0,"genera soles", 20,0);
            tablero.set(pos, g);
            this.nSoles=this.nSoles-20;
        }else{
            if (this.nSoles<20 && tablero.get(pos)!=null) {
                System.out.println("No tiene suficientes soles y la casilla está ocupada");
            }else if (this.nSoles<20) {
                System.out.println("No tiene suficientes soles");
            }else if(tablero.get(pos) !=null){
                System.out.println("La casilla está ocupada");
            }
        }
    }
    /**
     * Lo mismo que en el metodo anterior solo que para los objetos Lanzaguisantes.
     */
    public void plantarLanzaguisantes(int fila, int columna){
        int pos= fila* nColumnas+columna;
        if (this.nSoles>=50 && tablero.get(pos)==null){
            Lanzaguisantes l= new Lanzaguisantes (3,1,"dispara recto hacia delante", 50,1,"linea recta");
            tablero.set(pos, l);
            this.nSoles=this.nSoles-50;
        }else{
            if (this.nSoles<50 && tablero.get(pos)!=null) {
                System.out.println("No tiene suficientes soles y la casilla está ocupada");
            }else if (this.nSoles<50) {
                System.out.println("No tiene suficientes soles");
            }else if(tablero.get(pos) !=null){
                System.out.println("La casilla está ocupada");
            }
        }
    }
    /**
     * Lo mismo que los métodos anteriores pero para objetos Nuez.
     */
    public void plantarNuez(int fila, int columna){
        int pos= fila*nColumnas+columna;
        if (this.nSoles>=20 && tablero.get(pos)==null){
            Nuez n= new Nuez (10,0,"recibe daño", 50,0);
            tablero.set(pos, n);
            this.nSoles=this.nSoles-20;
        }else{
            if (this.nSoles<20 && tablero.get(pos)!=null) {
                System.out.println("No tiene suficientes soles y la casilla está ocupada");
            }else if (this.nSoles<20) {
                System.out.println("No tiene suficientes soles");
            }else if(tablero.get(pos) !=null){
                System.out.println("La casilla está ocupada");
            }
        }
    }
    /**
     * Recorremos todo el array tablero en busca de girasoles, y dependiendo de cuantos nos encontremos nos
     * iran añadiendo mas o menos soles.
     */
    public void ingresarSoles(){
        for (int i = 0; i < tablero.size(); i++) {
            if (tablero.get(i)!=null && tablero.get(i).getClass().getSimpleName().equals("Girasol")) {
                Girasol g= (Girasol) tablero.get(i);
                if (g.getFrecuencia()!=0) {
                    g.restarFrecuencia();
                }else{
                    this.nSoles=this.nSoles+g.getSolesGen();
                    g.setFrecuencia(2);
                }
            }
        }
    }/**
     * Lo que pretendemos hacer con este metodo es, primero localizar donde estan los Lanzaguisantes en el tablero, y despues
     * comprobamos si hay algun zombie en su misma fila, si es asi le va restando vida por cada turno.Y si el zombie se queda sin vida
     * este desaparece del tablero.
     */
    public void dispararRecto(){
        for (int i = 0; i < tablero.size(); i++) {
            if (tablero.get(i)!=null && (tablero.get(i).getClass().getSimpleName().equals("Lanzaguisantes"))) {
                int filaDisparo= 1 / nColumnas;
                int filaFinal= (filaDisparo+1) * nColumnas;
                for (int j = i; j< filaFinal; j++) {
                    if (tablero.get(j)!=null && (tablero.get(j).getClass().getSimpleName().equals("ZombieComun"))) {
                        Lanzaguisantes l=(Lanzaguisantes) tablero.get(i);
                        ZombieComun z= (ZombieComun) tablero.get(j);
                        z.recibirDaño(l.getDaño());
                        System.err.println(l.getDaño());
                        if (z.getVida()==0) {
                            tablero.set(j, null);
                        }
                        break;
                    }else if (tablero.get(j)!=null && (tablero.get(j).getClass().getSimpleName().equals("Caracubo"))) {
                        Lanzaguisantes l=(Lanzaguisantes) tablero.get(i);
                        Caracubo c= (Caracubo) tablero.get(j);
                        c.recibirDaño(l.getDaño());
                        System.err.println(l.getDaño());
                        if (c.getVida()==0) {
                            tablero.set(j, null);
                        }
                        break;
                    } else if (tablero.get(j)!=null && (tablero.get(j).getClass().getSimpleName().equals("Deportista"))) {
                        Lanzaguisantes l=(Lanzaguisantes) tablero.get(i);
                        Deportista d = (Deportista) tablero.get(j);
                        d.recibirDaño(l.getDaño());
                        System.err.println(l.getDaño());
                        if (d.getVida()==0) {
                            tablero.set(j, null);
                        }
                        break;
                    }
                }
            }
        }
    }
    /**
     * Este metodo es para los objetos de tipo ZombieComun, y sirve para ver donde se encuentra cada uno en el tablerom y asi
     * saber si tiene a una casilla de distancia a un objeto de tipo girasol o Lanzaguisante y hacerle daño.
     * Ademas sirve para que el zombie avanze una casilla cada turno si no tiene nada delante.
     */
    public void avanzar(){
        for (int i = 0; i < tablero.size(); i++) {
            if (tablero.get(i)!=null && (tablero.get(i).getClass().getSimpleName().equals("ZombieComun"))) {
                if (tablero.get(i-1)!=null && (tablero.get(i-1).getClass().getSimpleName().equals("Girasol") || (tablero.get(i-1).getClass().getSimpleName().equals("Lanzaguisantes")) || (tablero.get(i-1).getClass().getSimpleName().equals("Nuez")))) {
                    tablero.get(i-1).recibirDaño(tablero.get(i).getDaño());
                    if (tablero.get(i-1).getVida()<=0) {
                        tablero.set(i-1,null);
                    }
                }else{
                    ZombieComun z= (ZombieComun) tablero.get(i);
                    if (z.getVelocidad()!=1) {
                        z.setVelocidad(z.getVelocidad()-1);
                    }else{
                        if(tablero.get(i-1)==null){
                            tablero.set(i-1, z);
                            tablero.set(i, null);
                            z.setVelocidad(2);
                        }
                    }
                }
            }else if (tablero.get(i)!=null && (tablero.get(i).getClass().getSimpleName().equals("Caracubo"))) {
                if (tablero.get(i-1)!=null && (tablero.get(i-1).getClass().getSimpleName().equals("Girasol") || (tablero.get(i-1).getClass().getSimpleName().equals("Lanzaguisantes")) || (tablero.get(i-1).getClass().getSimpleName().equals("Nuez")))) {
                    tablero.get(i-1).recibirDaño(tablero.get(i).getDaño());
                    if (tablero.get(i-1).getVida()<=0) {
                        tablero.set(i-1,null);
                    }
                }else{
                    Caracubo c= (Caracubo) tablero.get(i);
                    if (c.getVelocidad()!=1) {
                        c.setVelocidad(c.getVelocidad()-1);
                    }else{
                        if(tablero.get(i-1)==null){
                            tablero.set(i-1, c);
                            tablero.set(i, null);
                            c.setVelocidad(4);
                        }
                    }
                }
            }else if (tablero.get(i)!=null && (tablero.get(i).getClass().getSimpleName().equals("Deportista"))) {
                if (tablero.get(i-1)!=null && (tablero.get(i-1).getClass().getSimpleName().equals("Girasol") || (tablero.get(i-1).getClass().getSimpleName().equals("Lanzaguisantes")) || (tablero.get(i-1).getClass().getSimpleName().equals("Nuez")))) {
                    tablero.get(i-1).recibirDaño(tablero.get(i).getDaño());
                    if (tablero.get(i-1).getVida()<=0) {
                        tablero.set(i-1,null);
                    }
                }else{
                    Deportista d= (Deportista) tablero.get(i);{
                            tablero.set(i-1, d);
                            tablero.set(i, null);
                            d.setVelocidad(1);
                        }
                    }
                }
            }
        }
    
    /**
     * Con este método se elige un número aleatorio entre 0 y 2 para seleccionar entre los 3 tipos 
     * de zombies creados hasta ahora.
     */
    
    public int elegirZombie(){
        Random r = new Random();
        int numZombie = r.nextInt(3);
        return numZombie;
    }
    /**
     * Este metodo es simplemente para que denpendiendo de la dificultad que eleija el jugador, se generen los zombies
     * al final del tablero y con mas o menos cantidad de ellos.
     */
    public void generarZombie(){
        int pos=nColumnas -1;
        int nZombie=elegirZombie();
        ArrayList<Integer> posPosibles= new ArrayList<>();
        for (int i = 0; i < nFilas; i++) {
            if (tablero.get(pos)==null) {
                posPosibles.add(pos);
                pos=pos+nColumnas;
            }
        }
        Collections.shuffle(posPosibles);
        if (this.modo.equals("BAJA")) {
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if (resultado==0 && !posPosibles.isEmpty()) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                }
            }
        }else if (this.modo.equals("MEDIA")) {
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if ((resultado==0||resultado==1) && !posPosibles.isEmpty()) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                }
            }
            
        }else if (this.modo.equals("ALTA")) {
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if (resultado==0 && !posPosibles.isEmpty()) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                }
                if (resultado==1 && posPosibles.size()>=2) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                    nZombie=elegirZombie();
                    
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                    }
                if (resultado==1 && posPosibles.size()>=1) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                }
                }
        }else if (this.modo.equals("IMPOSIBLE")){
            if (!posPosibles.isEmpty() && contZombies>0) {
                Random r= new Random();
                int suelo=0;
                int techo=3;
                int resultado= r.nextInt(techo-suelo)+ suelo;
                if (resultado==0) {
                    int spawnZombies;
                    if (posPosibles.size()>=4) {
                        spawnZombies=4;
                    }else{
                    spawnZombies=posPosibles.size();
                    }
                    for (int i = 0; i < spawnZombies; i++) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                    }
                }else if (resultado==1) {
                    int spawnZombies;
                    if (posPosibles.size()>=3) {
                        spawnZombies=3;
                    }else{
                    spawnZombies=posPosibles.size();
                    }
                    for (int i = 0; i < spawnZombies; i++) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                    }
                }else if (resultado==2) {
                    int spawnZombies;
                    if (posPosibles.size()>=2) {
                        spawnZombies=2;
                    }else{
                    spawnZombies=posPosibles.size();
                    }
                    for (int i = 0; i < spawnZombies; i++) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                    }
                }
                else if (resultado==3) {
                    if (!posPosibles.isEmpty()) {
                    if (nZombie==0) {
                    ZombieComun z= new ZombieComun(5,1,"Avanza y come plantas",2);
                    tablero.set(posPosibles.get(0), z);
                    contZombies=contZombies-1;
                    }
                    else if (nZombie==1) {
                    Caracubo c= new Caracubo(8,1,"Avanza y come plantas",4);
                    tablero.set(posPosibles.get(0), c);
                    contZombies=contZombies-1;    
                    }
                    else{
                    Deportista d= new Deportista(2,1,"Avanza y come plantas",1);
                    tablero.set(posPosibles.get(0), d);
                    contZombies=contZombies-1; 
                    }
                    }
                }
            }
        }
    }
    /**
     * Por cada turno que pase, este metodo llamara a los tres metodos correspondientes que tienen que ver con las acciones
     * que se tienen que hacer cada ver que se pasa de turno.
     */
    public void pasarTurno(){
        avanzar();
        dispararRecto();
        ingresarSoles();

    }
    /**
     * Con este metodo comprobamos el estado de la partida, si un zombie ha llegado al final o no.
     * @return boolean Si nos devuelve false los zombies no han llegado todavia, si nos devuelve true la partida se acaba porque los
     * zombies han llegado a la columna 0.
     */
    public boolean finPartida(){
        int pos=0;
        for (int i = 0; i < nFilas; i++) {
            if (tablero.get(pos)!=null && tablero.get(pos).getClass().getSimpleName().equals("ZombieComun")) {
                return true;
            }
            pos=pos+nColumnas;
        }
        return false;
    }
    /**
     * Con este metodo enseñamos al usuario los distintos comandos que puede utilizar, auque nosotros los hayamos segmentado
     * siguen teniendo la misma estructura.
     */
    public void ayuda(){
        System.out.println("N <filas> <columnas> <Dificultad>: Nueva partida (Dificultad: BAJA, MEDIA, ALTA, IMPOSIBLE).");
        System.out.println("G <fila> <columna>: colocar girasol. Únicamente se podrá añadir un nuevo Girasol por turno y si tiene el número suficiente de soles. No podrá añadir un Girasol en una casilla ocupada por otra planta o por un zombi.");
        System.out.println("L <fila> <columna>: colocar LanzaGuisantes. Únicamente se podrá añadir un nuevo LanzaGuisantes por turno y si tiene el número suficiente de soles. No podrá añadir un LanzaGuisantes en una casilla ocupada por otra planta o por un zombi.");
        System.out.println("S: Salir de la aplicación.");
        System.out.println("<Enter>: Pasar Turno");
    }
}
