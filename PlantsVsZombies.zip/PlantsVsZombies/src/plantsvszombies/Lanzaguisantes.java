/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author jonathan y alejandro
 */
public class Lanzaguisantes extends Planta {
    private String alcance;
/**
 * Constructor de la clase Lanzaguisantes que hereda los atributos de la clase Planta
 * @param vida
 * @param daño
 * @param comportamiento
 * @param coste
 * @param frecuencia
 * @param alcance 
 */
    public Lanzaguisantes(int vida, int daño, String comportamiento, int coste, int frecuencia, String alcance) {
        super(vida, daño, comportamiento, coste, frecuencia);
        this.alcance=alcance;
    }
/**
 * Metodos getter y setter del alcance del lanzaguisantes
 * 
 */
    public String getAlcance() {
        return alcance;
    }

    public void setAlcance(String alcance) {
        this.alcance = alcance;
    }
    
}
