/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author aleja
 */
public class Lanzaguisantes extends Planta {
    private int alcance;

    public Lanzaguisantes(int vida, int daño, String comportamiento, int coste, int frecuencia, int alcance) {
        super(vida, daño, comportamiento, coste, frecuencia);
        this.alcance=alcance;
    }

    public int getAlcance() {
        return alcance;
    }

    public void setAlcance(int alcance) {
        this.alcance = alcance;
    }
    
}
