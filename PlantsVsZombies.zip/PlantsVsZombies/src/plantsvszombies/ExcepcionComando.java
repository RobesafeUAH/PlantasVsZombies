/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author aleja
 */
public class ExcepcionComando {
    public static String dificultad(String modo){
        if ("BAJA".equals(modo)) {
            modo="BAJA";
            return modo;
        }else if ("MEDIA".equals(modo)) {
            modo="MEDIA";
            return modo;
        }else if ("ALTA".equals(modo)) {
            modo="ALTA";
            return modo;
        }else if("IMPOSIBLE".equals(modo)){
            modo="IMPOSIBLE";
            return modo;
        }else{
            modo="BAJA";
            return modo;
        }
    }
    public static boolean cadenaAInt(String comando1, String comando2){
       int resultado1;
       int resultado2;
       boolean bool=true;
       try{
          resultado1 = Integer.parseInt(comando1);
          resultado2 = Integer.parseInt(comando2);
       }catch(NumberFormatException e){
           bool=false;
       }
       finally{
           return bool;
        }
    }
    
    public static boolean division(String comando){
     boolean bool=true;
     try{
        String cPlanta=comando.split(" ")[0];
        String cFila=comando.split(" ")[1];
        String cColumna=comando.split(" ")[2];
     }catch(ArrayIndexOutOfBoundsException i){
         bool=false;
     }
     return bool;
    }
}
