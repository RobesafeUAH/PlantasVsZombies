package plantsvszombies;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jonathan y alejandro
 */

public class Personaje {
    private int vida;
    private int daño;
    private String comportamiento;
/**
 * Constructor de la clase personaje que heredarán todos los personjaes que aparezcan en el juego
 * 
 */
    public Personaje(int vida, int daño, String comportamiento) {
        this.vida = vida;
        this.daño = daño;
        this.comportamiento = comportamiento;
    }
/**
 * Metodos getter y setter que permiten consultar y modificar los atributos de los personajes
 * 
 */
    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getDaño() {
        return daño;
    }

    public void setDaño(int daño) {
        this.daño = daño;
    }

    public String getComportamiento() {
        return comportamiento;
    }

    public void setComportamiento(String comportamiento) {
        this.comportamiento = comportamiento;
    }
    /**
     * Función que permite restar vida al objetivo de un ataque
     * @param daño 
     */
    public void recibirDaño(int daño){
        this.vida=vida-daño;
    }
    
}
