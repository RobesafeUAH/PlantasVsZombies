/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantsvszombies;

/**
 *
 * @author aleja
 */
public class Nuez extends Planta{
    
    public Nuez(int vida, int daño, String comportamiento, int coste, int frecuencia) {
        super(vida, daño, comportamiento, coste, frecuencia);
    }
    
}
